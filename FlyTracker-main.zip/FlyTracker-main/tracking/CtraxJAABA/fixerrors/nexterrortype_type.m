function type_list = nexterrortype_type()
type_list = {'Track Birth','birth',
  'Track Death','death',
  'Match Cost Ambiguity','swap',
  'Large Jump','jump',
  'Large Change in Orientation','orientchange',
  'Velocity & Orient. Mismatch','orientvelmismatch',
  'Large Major Axis','largemajor'};
