function result = fif(test, result_if_true, result_if_false)
    if test ,
        result = result_if_true ;
    else
        result = result_if_false ;
    end
end
