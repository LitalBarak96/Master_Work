function nop()
    % do nothing
end
